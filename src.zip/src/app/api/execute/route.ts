import { NextResponse } from 'next/server';
import { exec } from 'child_process';
import path from 'path';
import { promisify } from 'util';
import os from 'os';

const execAsync = promisify(exec);

export async function POST(request: Request) {
    try {
        const { scriptPath, c2Host } = await request.json();

        if (!scriptPath) {
            return NextResponse.json({ error: 'No script path provided' }, { status: 400 });
        }

        // Security: Minimize injection risk
        const safePath = path.normalize(scriptPath).replace(/^(\.\.(\/|\\|$))+/, '');
        const fullPath = path.join(process.cwd(), 'src', safePath);

        // Determine Environment
        const isWindows = os.platform() === 'win32';

        console.log(`[API] Executing: ${fullPath} with C2: ${c2Host}`);

        let command = '';

        if (isWindows) {
            // Windows Execution
            command = `powershell -NoProfile -ExecutionPolicy Bypass -File "${fullPath}"`;
        } else {
            // Dev/Mac Simulation: If .ps1, warn we are simulating. 
            // If we want real testing on Mac we can require pwsh, but purely simulated output is safer for now.
            // Check if user has pwsh installed?
            // Ideally we just grep the script for 'Write-Host' content or run a simulation script.
            // For simplicity in this lab: rely on the script being executable on the host if possible, 
            // OR wrapper to just echo "Simulated Execution on Non-Windows Host"

            // Actually, we can try to run 'pwsh' if installed (PowerShell Core).
            // If not, we fall back to a dummy success message.
            command = `if command -v pwsh &> /dev/null; then pwsh -File "${fullPath}"; else echo "Warning: Non-Windows Host. Simulated Success for: ${safePath}"; fi`;
        }

        const { stdout, stderr } = await execAsync(command, {
            env: { ...process.env, C2_HOST: c2Host || '127.0.0.1' },
            shell: isWindows ? 'powershell.exe' : '/bin/bash'
        });

        return NextResponse.json({
            success: true,
            output: stdout,
            error: stderr
        });

    } catch (error: any) {
        console.error('Execution Error:', error);
        return NextResponse.json({
            success: false,
            error: error.message
        }, { status: 500 });
    }
}
