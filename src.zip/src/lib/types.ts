export interface MitreTechnique {
  id: string; // e.g. T1059.004
  name: string; // e.g. Command and Scripting Interpreter: Bash
  url: string;
}

export type AdversaryName = 'APT1' | 'APT28' | 'Scattered Spider' | 'Red Team Ops' | 'APT45' | 'Mustang Panda' | 'Wizard Spider';

export interface Scenario {
  id: string;
  name: string;
  adversary: AdversaryName;
  description: string;
  mitreTechniques: MitreTechnique[];
  scriptPath: string; // Path relative to project root or absolute path on VM
  estimatedDuration: string;
  difficulty: 'Easy' | 'Medium' | 'Hard';
}

export interface Campaign {
  id: string;
  adversary: AdversaryName;
  name: string;
  description: string;
  steps: string[]; // List of Scenario IDs to run in order
  image?: string; // Optional hero image for the campaign
}

// Atomic Scenarios
export const SCENARIOS: Scenario[] = [
  {
    id: 'recon-local',
    name: 'Host Reconnaissance (PowerShell)',
    adversary: 'Red Team Ops',
    description: 'Enumerates local network connections and running processes to identify key assets.',
    mitreTechniques: [
      { id: 'T1049', name: 'System Network Connections Discovery', url: 'https://attack.mitre.org/techniques/T1049/' },
      { id: 'T1057', name: 'Process Discovery', url: 'https://attack.mitre.org/techniques/T1057/' }
    ],
    scriptPath: 'scenarios/recon_local.ps1',
    estimatedDuration: '2 mins',
    difficulty: 'Easy'
  },
  {
    id: 'priv-esc',
    name: 'Privilege Escalation Check',
    adversary: 'APT28',
    description: 'Checks current privileges and simulates enabling SeDebugPrivilege.',
    mitreTechniques: [
      { id: 'T1134', name: 'Access Token Manipulation', url: 'https://attack.mitre.org/techniques/T1134/' }
    ],
    scriptPath: 'scenarios/priv_esc.ps1',
    estimatedDuration: '1 min',
    difficulty: 'Medium'
  },
  {
    id: 'lateral-dc',
    name: 'Lateral Movement to Domain Controller',
    adversary: 'APT28',
    description: 'Attempts to verify connectivity and simulate administrative share access to the DC (10.160.37.16).',
    mitreTechniques: [
      { id: 'T1021.002', name: 'Remote Services: SMB', url: 'https://attack.mitre.org/techniques/T1021/002/' }
    ],
    scriptPath: 'scenarios/lateral_dc.ps1',
    estimatedDuration: '5 mins',
    difficulty: 'Hard'
  },
  {
    id: 'c2-check',
    name: 'C2 Connectivity Check',
    adversary: 'Scattered Spider',
    description: 'Verifies DNS resolution and TCP connectivity to the configured C2 infrastructure.',
    mitreTechniques: [
      { id: 'T1071', name: 'Application Layer Protocol', url: 'https://attack.mitre.org/techniques/T1071/' }
    ],
    scriptPath: 'scenarios/c2_check.ps1',
    estimatedDuration: '2 mins',
    difficulty: 'Easy'
  },
  {
    id: 'persistence-reg',
    name: 'Persistence (Registry)',
    adversary: 'APT1',
    description: 'Creates a simulated malicious Run key in HKCU.',
    mitreTechniques: [
      { id: 'T1547.001', name: 'Registry Run Keys', url: 'https://attack.mitre.org/techniques/T1547/001/' }
    ],
    scriptPath: 'scenarios/persistence.ps1',
    estimatedDuration: '1 min',
    difficulty: 'Medium'
  },
  {
    id: 'defense-evasion',
    name: 'Defense Evasion (Clear Logs)',
    adversary: 'Red Team Ops',
    description: 'Simulates clearing the Security Event Log.',
    mitreTechniques: [
      { id: 'T1070.001', name: 'Indicator Removal: Clear Windows Event Logs', url: 'https://attack.mitre.org/techniques/T1070/001/' }
    ],
    scriptPath: 'scenarios/defense_evasion.ps1',
    estimatedDuration: '2 mins',
    difficulty: 'Medium'
  },
  {
    id: 'cred-dump',
    name: 'Credential Dumping (Active)',
    adversary: 'APT1',
    description: 'Simulates dumping LSASS memory using rundll32 and comsvcs.dll.',
    mitreTechniques: [
      { id: 'T1003.001', name: 'OS Credential Dumping: LSASS Memory', url: 'https://attack.mitre.org/techniques/T1003/001/' }
    ],
    scriptPath: 'scenarios/cred_dump.ps1',
    estimatedDuration: '3 mins',
    difficulty: 'Hard'
  }
];

// Defined Campaigns
export const CAMPAIGNS: Campaign[] = [
  {
    id: 'apt28-campaign',
    adversary: 'APT28',
    name: 'Operation XAgent',
    description: 'Simulates a typical APT28 intrusion chain involving recon, privilege escalation, and lateral movement targeting high-value infrastructure.',
    steps: ['recon-local', 'priv-esc', 'lateral-dc', 'cred-dump'] // Example chain
  },
  {
    id: 'apt1-campaign',
    adversary: 'APT1',
    name: 'Operation Comment Crew',
    description: 'A noise-heavy campaign focusing on persistence and credential harvesting.',
    steps: ['recon-local', 'persistence-reg', 'cred-dump']
  },
  {
    id: 'scattered-spider-campaign',
    adversary: 'Scattered Spider',
    name: 'Cloud & Identity Siege',
    description: 'Focuses on connecting to C2, evading defenses, and establishing persistence for long-term access.',
    steps: ['c2-check', 'defense-evasion', 'persistence-reg', 'priv-esc']
  },
  {
    id: 'apt45-campaign',
    adversary: 'APT45',
    name: 'North Korean Info Stealer',
    description: 'Rapid collection of information and credentials.',
    steps: ['recon-local', 'defense-evasion', 'cred-dump']
  },
  {
    id: 'mustang-panda-campaign',
    adversary: 'Mustang Panda',
    name: 'PlugX Propagation',
    description: 'Lateral movement and C2 beaconing focus.',
    steps: ['recon-local', 'lateral-dc', 'c2-check']
  },
  {
    id: 'wizard-spider-campaign',
    adversary: 'Wizard Spider',
    name: 'Conti/Ryuk Precursor',
    description: 'The prelude to a ransomware attack: Recon, C2 verification, and spreading via SMB.',
    steps: ['recon-local', 'c2-check', 'lateral-dc', 'defense-evasion']
  }
];
